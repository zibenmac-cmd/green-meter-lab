# 绿电实验室 Web 2.0

正式网址：https://green-meter-lab-v2.ziben-mac.workers.dev

中文能源实验工作台，部署于用户自己的 Cloudflare Workers + D1。真实记录及管理接口需要管理员口令，公共页面默认展示明确标记的模拟数据。管理员访问说明仅保存在本机，不进入 Git 或交付源码包。

## 功能

- 能源概览：日期筛选、记录电量、估算电费与碳排、日均记录电量、峰值、用电构成。
- 电器与使用率：电量、运行时间、运行占观测比、大功率时长排名、铭牌功率目录与编号复制。
- 节能洞察：根据所选记录生成建议，待机分析、目标情景；连续真实摘要可进行 AR(6) 未来 30 秒参考外推。
- 电器学习：独立约 20 秒状态段、完整段留出验证、未知拒识、样本复核与 Mac 学习 JSON 导入。
- 记录与接入：带密钥的上传接口、CSV 导入导出、重复记录处理、断连与计量重置提示、原始 ADC 波形。
- 设置：电价、碳排系数、大功率阈值、改善目标。

## 工程

`web/` 是 React 页面；`worker/index.ts` 是 API；`migrations/` 是 D1 结构；`lib/energy-v2.mjs` 是统计；`lib/learning-v2.mjs` 是与 Mac 版兼容的 adc-shape-v1 特征和分类器；`adapters/socket_bridge_v2.py` 是 Python 3 标准库本机采集桥。

原工程目录中其他旧版文件不参与本版构建。交付源码包只包含本版所需文件，旧版本独立留档。

## 本机开发和测试

需要 Node.js 22+、pnpm、Python 3。在忽略的 `.dev.vars` 中配置独立随机 `ADMIN_KEY` 和 `SESSION_SECRET`，不要提交凭据。

```sh
pnpm install --frozen-lockfile
pnpm exec wrangler d1 migrations apply green-meter-lab-v2 --local
pnpm build
pnpm preview
# 另一个终端运行前端 5173，代理 API 到后端 8787
pnpm dev
pnpm test
node tests/web-v2/api.local.mjs
```

API 集成测试固定连接本机，只产生本机合成测试记录，不能将这些样本上传生产环境。协议复核可运行 `python3 adapters/socket_bridge_v2.py --self-test /path/to/socket128.bin`。

## 发布

`wrangler.jsonc` 已绑定本项目账号及专用 D1。迁移到其他账号时替换对应 ID。

```sh
pnpm exec wrangler login --scopes account:read user:read workers_scripts:write d1:write
pnpm exec wrangler d1 migrations apply green-meter-lab-v2 --remote
pnpm build
pnpm deploy
pnpm exec wrangler secret bulk .dev.vars
```

ADMIN_KEY 是管理员访问口令；SESSION_SECRET 用于签名 8 小时 HttpOnly / Secure / SameSite=Strict 登录会话。未配置时私有 API 关闭。网页生成的采集密钥仅允许上传，服务器只保存其哈希，明文仅生成时显示。

## 现场接入

1. 手动连接插座 Wi-Fi，默认目标 `192.168.1.2:8266`。不要与 Mac 软件同时占用设备 TCP。
2. 网页切换真实记录并登录，登记电器，在“记录与接入”生成采集密钥，下载程序和说明。
3. `python3 socket_bridge.py --url https://green-meter-lab-v2.ziben-mac.workers.dev`，按提示隐藏输入采集密钥。
4. 程序被动接收，不发送查询、启动、停止或继电器命令。供电仍通过已有 Mac 控制软件或设备按钮人工确认。
5. 原始 BIN 和上传队列保存于 `~/Documents/绿电实验室Web采集`。插座热点没有互联网时先采集，恢复互联网后运行相同命令加 `--sync-only` 补传。旧记录不会显示为实时在线。
6. 同时可连接插座和互联网时可用网页采集学习段；离线场景继续用 Mac 版采样，之后导入其学习 JSON。网页重新训练，不直接信任外来模型。
7. 人工标注可用 `--appliance-id 网页复制的编号 --state running/off/standby`，否则为未知或由通过验证的兼容模型参考匹配。

## 统计与识别边界

- 单插座分时观测，不分解多个同时使用的负载。
- 有有效累计读数时取差；无累计读数时对连续功率积分。参考 ADC 系数尚未实物标定，显示估算；负功率不取绝对值充当耗电。
- 超过 60 秒、会话或质量改变、负计量差值均不补算，不当作节电。TCP 重连后新建会话。
- Asia/Shanghai 自然日，每次筛选 1–31 天。日均按有记录日期平均，并非完整日比较。
- 运行占观测比 = 某电器标注或识别为运行的有效时间 / 全部有效设备观测时间。大功率比例使用同样分母。未知状态不算运行，铭牌功率只用于筛选。
- 同设备同时间记录幂等，已保存重复记录忽略。CSV 不改变在线状态。自动记录超过 60 秒未更新显示中断。
- 每类至少 3 个独立约 20 秒学习段、至少两类，完整段留出验证平衡准确率 ≥80% 才启用。连续 3 窗口稳定匹配后标记；相似、未见过或不兼容来源显示未知。验证分数不代表未知电器准确率。
- 6400 Hz 是配置值，仍需实测采样率、通道比例、零点及极性。
- 预测需要至少连续 90 秒每秒真实摘要；断连旧记录不显示当前预测，不能预知人为开关机。
- 电费、碳排、目标节电均为估算；0.785 kg CO₂/kWh 是计划默认值。目标情景不是已实现节省。
- 云端保存摘要和学习特征，高频原始 BIN 保留在 Mac。

## 验证记录

2026-10-27：16 个单元测试、TypeScript 检查、Vite 构建通过。本机 D1 接口通过登录与私有权限、重复处理、1 kWh 统计、CSV 导出、来源隔离、设备摘要、学习验证及停用后模型失效检查。原实测 BIN 复核 242 个有效帧、0 个校验失败；这是协议复核。本次没有连接现场插座、训练用户电器或完成计量标定。已检查 1440 px 电脑与 390 px 手机布局。
