import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({root:'web',plugins:[react()],css:{postcss:{plugins:[]}},build:{outDir:'../dist/web',emptyOutDir:true},server:{port:5173,proxy:{'/api':'http://127.0.0.1:8787'}}});
